Opened 


# Notes

## To run in background

nohup python3 /home/donagh/Applications/flask_htmx_lanner/app.py &
nohup /usr/bin/python3 /home/donagh/Applications/flask_htmx_lanner/app.py &


## What is unpkg for?
I am calling for the htmx package from https://unpkg.com/ instead of having it local. That needs to be fixed.
Copied htmx.min.js to <script src="/home/donagh/Applications/flask_htmx_lanner/js/htmx.min.js"></script> and inserted into
index.html



