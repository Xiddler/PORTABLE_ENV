Created 2024-10-15


# Location
Lenovo Legion::\Users\don_l\Windows_dot_emacs.zip


Toshiba: anonymous /home/donagh/samba/anonymous_shared_directory/EMACS/Windows_dot_emacs.zip

# Bedrock emacs
This emacs init.el file and early-init.el files were based on bedrock-emacs

https://github.com/ebittleman/emacs-bedrock

# zim-wiki

EDITORS:emacs:Windows 11:Varieties of emacs on Windows:vanilla emacs

# Lenovo Legion Laptop

C:\Users\don_l\.emacs.d 
which was backed up in a .zip file to Toshiba anonymous directory with packages included


